def handler(event, context):
    message = "Hello World"
    return {
        "message": message
    }
